﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnLogin_click(object sender, EventArgs e)
    {
        try
        {
            string message = string.Empty;

            if (txtusername.Text.Trim().Length == 0)
            {
                message += "Enter Username.\\n";
            }

            if (txtpassword.Text.Trim().Length == 0)
            {
                message += "Enter Password.";
            }

            if (message.Length > 0)
            {
                showAlert(message);
            }
            else
            {
                DataTable dt;
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
                {
                    conn.Open();
                    SqlCommand cmd = conn.CreateCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "[dbo].[proc_Library]";
                    cmd.Parameters.AddWithValue("@flag", "login");
                    cmd.Parameters.AddWithValue("@username", txtusername.Text.Trim());
                    cmd.Parameters.AddWithValue("@name", DBNull.Value);
                    cmd.Parameters.AddWithValue("@email", DBNull.Value);
                    cmd.Parameters.AddWithValue("@phone_number", DBNull.Value);
                    cmd.Parameters.AddWithValue("@password", txtpassword.Text.Trim());
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    dt = new DataTable();
                    da.Fill(dt);
                    conn.Close();
                }

                if (dt.Rows.Count > 0)
                {
                    Response.Redirect("home.aspx?uid=" + Convert.ToString(dt.Rows[0][0]));
                }
                else
                {
                    showAlert("Incorrect username/password.");
                }
            }
        }
        catch (Exception ex)
        {
            showAlert(ex.Message.ToString());
        }
    }

    protected void showAlert(string message)
    {
        ScriptManager.RegisterStartupScript(Page, GetType(), "JavaFunction", "alert('" + message + "');", true);
    }

}
    
