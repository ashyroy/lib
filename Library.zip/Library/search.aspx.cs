﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Services;


public partial class search : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSearch_click(object sender, EventArgs e)
    {
        try
        {
            string errors = string.Empty;

            /*if (Convert.ToInt32(lblUsernameCheck.Value) != 1)
            {
                errors += "Enter a proper Username.\\n";
            }*/

            if (txtbookname.Text.Trim().Length == 0)
            {
                errors += "Enter a bookname.\\n";
                showAlert(errors);
            }
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
            {
                conn.Open();
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "[dbo].[proc_Library]";
                cmd.Parameters.AddWithValue("@flag", "search");
                cmd.Parameters.AddWithValue("@bookname", txtbookname.Text.Trim());
                cmd.Parameters.AddWithValue("@author", DropDownList3.Text.Trim());
                cmd.Parameters.AddWithValue("@bookid", DropDownList3.Text.Trim());
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message.ToString());
        }

    }
}