﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Services;


public partial class Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnRegister_click(object sender, EventArgs e)
    {
        try
        {
            string errors = string.Empty;

            /*if (Convert.ToInt32(lblUsernameCheck.Value) != 1)
            {
                errors += "Enter a proper Username.\\n";
            }*/

            if (txtusername.Text.Trim().Length == 0)
            {
                errors += "Enter a Username.\\n";
                showAlert(errors);
            }
            else
            {
                int status = checkUsername_(txtusername.Text.Trim().ToString());
                if (status == 0)
                {
                    if (txtname.Text.Trim().Length == 0)
                    {
                        errors += "Enter a Name.\\n";
                    }

                    if (!(validEmail(txtemail.Text.Trim())))
                    {
                        errors += "Enter a valid Email Id.\\n";
                    }

                    if (txtphone.Text.Trim().Length != 10)
                    {
                        errors += "Enter a valid Phone number.\\n";
                    }

                    if (txtpassword.Text.Trim().Length == 0)
                    {
                        errors += "Enter a Password.\\n";
                    }
                    else
                    {
                        if (txtconfirmpassword.Text.Trim().Length == 0)
                        {
                            errors += "Confirm Password.\\n";
                        }
                        else
                        {
                            if (txtconfirmpassword.Text.Trim() != txtpassword.Text.Trim())
                            {
                                errors += "Password and Confirm Password is not matching.\\n";
                            }
                        }
                    }

                    if (errors.Length > 0)
                    {
                        showAlert(errors);
                    }
                    else
                    {
                        using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString))
                        {
                            conn.Open();
                            SqlCommand cmd = conn.CreateCommand();
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "[dbo].[proc_students]";
                            cmd.Parameters.AddWithValue("@flag", "register");
                            cmd.Parameters.AddWithValue("@username", txtusername.Text.Trim());
                            cmd.Parameters.AddWithValue("@name", txtname.Text.Trim());
                            cmd.Parameters.AddWithValue("@email", txtemail.Text.Trim());
                            if (txtphone.Text.Trim().Length == 0)
                            {
                                cmd.Parameters.AddWithValue("@phone_number", DBNull.Value);
                            }
                            else
                            {
                                cmd.Parameters.AddWithValue("@phone_number", txtphone.Text.Trim());
                            }
                            cmd.Parameters.AddWithValue("@password", txtpassword.Text.Trim());
                            int i = cmd.ExecuteNonQuery();
                            if (i > 0)
                            {
                                showAlert("User registered successfully.");
                            }
                            else
                            {
                                showAlert("User not registered successfully.");
                            }
                            txtusername.Text = "";
                            txtname.Text = "";
                            txtemail.Text = "";
                            txtphone.Text = "";
                            txtpassword.Text = "";
                            txtconfirmpassword.Text = "";
                            conn.Close();
                        }
                    }
                }
                else
                {
                    showAlert("Username has already taken.");
                }
            }

        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message.ToString());
        }
    }

    private int checkUsername_(string v)
    {
        throw new NotImplementedException();
    }

    protected void showAlert(string message)
    {
        ScriptManager.RegisterStartupScript(Page, GetType(), "JavaFunction", "alert('" + message + "');", true);
    }

    protected bool validEmail(string email)
    {
        bool status = false;
        try
        {
            MailAddress mail = new MailAddress(email);
            status = true;
        }
        catch (Exception)
        {
            status = false;
        }
        return status;
    }


    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
}
    
